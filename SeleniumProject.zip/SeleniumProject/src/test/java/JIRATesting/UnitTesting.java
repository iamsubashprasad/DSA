package JIRATesting;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.devtools.DevTools;
//
//import com.google.common.base.Optional;

public class UnitTesting {

	public static void main(String[] args) throws InterruptedException {
		
		
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver","C:/Users/subas/eclipse-workspace/SeleniumProject/src/main/resources/Driver/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.get("https://id.atlassian.com/login");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.findElement(By.id("username")).sendKeys("subash129@gmail.com");
		driver.findElement(By.id("login-submit")).click();
		driver.findElement(By.id("password")).sendKeys("Alekhya#9876");
		driver.findElement(By.id("login-submit")).click();
		driver.findElement(By.cssSelector("[id='createGlobalItem']")).click();
		driver.findElement(By.xpath("(//span[@role='img' and @aria-label='open'])[2]")).click();
		Thread.sleep(2000);
		/*
		 * driver.executeCdpCommand(null, null); DevTools devTool =
		 * driver.getDevTools(); devTool.createSession();
		 */
		
		
		

	}

}
